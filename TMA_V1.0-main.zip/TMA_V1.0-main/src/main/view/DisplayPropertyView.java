package main.view;

import java.util.LinkedHashMap;
import java.util.Map;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import main.controller.PropertyController;
import main.model.ApartmentModel;
import main.model.CondoModel;
import main.model.HouseModel;
import main.model.PropertyModel;
import main.util.SceneController;
import main.util.builder.PropertyModelBuilder;
import main.util.builder.PropertyViewModelBuilder;

public class DisplayPropertyView implements Runnable {
	String propertyFlag;


	DisplayPropertyView() {	}

	DisplayPropertyView(String propertyVacancyStatusFlag) {
		this.propertyFlag = propertyVacancyStatusFlag;
	}

	// Creating SceneController Class Object
	SceneController sceneCtrl = new SceneController();

	// Event listener for the "Go Home Screen" button
	private void goHomeButtonClickListener(ActionEvent event) {
		sceneCtrl.switchToScene("Welcome Screen");
	}

	// Property Dummy Data
	static LinkedHashMap<Integer, PropertyModel> propertyList = new LinkedHashMap<Integer, PropertyModel>();

	// Load Property Data
	void setPropertyData(String propertyUpdate) {
		if (propertyUpdate.equalsIgnoreCase("All Property")) {
			PropertyModelBuilder pBuilder = new PropertyModelBuilder();
			PropertyViewModelBuilder pViewBuilder = new PropertyViewModelBuilder();
			PropertyModel pModel = pBuilder.build();
			PropertyView pView = pViewBuilder.build();
			PropertyController pController = new PropertyController(pModel, pView);
			DisplayPropertyView.propertyList = pController.displayPropertyController();
		} else if (propertyUpdate.equalsIgnoreCase("Vacant Property")) {
			PropertyModelBuilder pBuilder = new PropertyModelBuilder();
			PropertyViewModelBuilder pViewBuilder = new PropertyViewModelBuilder();
			PropertyModel pModel = pBuilder.build();
			PropertyView pView = pViewBuilder.build();
			PropertyController pController = new PropertyController(pModel, pView);
			DisplayPropertyView.propertyList = pController.displayVacantUnitsController();
		} else if (propertyUpdate.equalsIgnoreCase("Rented Property")) {
			PropertyModelBuilder pBuilder = new PropertyModelBuilder();
			PropertyViewModelBuilder pViewBuilder = new PropertyViewModelBuilder();
			PropertyModel pModel = pBuilder.build();
			PropertyView pView = pViewBuilder.build();
			PropertyController pController = new PropertyController(pModel, pView);
			DisplayPropertyView.propertyList = pController.displayRentedUnitsController();
		}
	}

	public void loadUI() {

		if (propertyList.size() == 0) {
			GridPane root = new GridPane();
			Text propertyVacancyStatusMessgae = new Text("Sorry, there are no properties in the system");
			Button homeScreenButton = new Button("Go Home Screen");
			homeScreenButton.setAlignment(Pos.CENTER);

			homeScreenButton.setOnAction((event) -> {
				this.goHomeButtonClickListener(event);
			});
	        

	        // Create a StackPane and add the Text node to it
	        StackPane stackPane = new StackPane(propertyVacancyStatusMessgae);
	        StackPane.setMargin(propertyVacancyStatusMessgae, new Insets(100,0,50,0));
			root.addRow(0, stackPane);
			root.addRow(1, homeScreenButton);
			root.setAlignment(Pos.TOP_CENTER);
			GridPane.setHalignment(homeScreenButton, javafx.geometry.HPos.CENTER);
	        GridPane.setValignment(homeScreenButton, javafx.geometry.VPos.CENTER);
			Scene displayPropertyScene = new Scene(root);
			
			sceneCtrl.addScene("Display Property", displayPropertyScene);
			sceneCtrl.switchToScene("Display Property");
			displayPropertyScene.getStylesheets().add(
					getClass().getResource("/main/styles/Tenant_Management_Main_Class_Style.css").toExternalForm());
		} else {
			int row = 0, col = 0, i;
			Text propertyDisplayMessage = new Text("List of properties are:");
			GridPane root = new GridPane();
			GridPane globalRoot = new GridPane();
			ScrollPane scrollPane = new ScrollPane(globalRoot);
			scrollPane.setFitToWidth(true);
			scrollPane.setFitToHeight(true);
			root.setAlignment(Pos.CENTER);
			root.setHgap(15);

			for (Map.Entry<Integer, PropertyModel> entry : propertyList.entrySet()) {
				int key = entry.getKey();
				PropertyModel property = entry.getValue();
				BorderPane card = new BorderPane();
				card.setPadding(new Insets(10));
				card.setStyle("-fx-background-color: #576CBC; -fx-background-radius: 10px;");

				FlowPane fPane = new FlowPane();
				if (property.getPropertyType().equalsIgnoreCase("Apartment")) {
					Text propertyID = new Text("PropertyID: " + String.valueOf(property.getPropertyID()));
					Text typeOfProperty = new Text("Property Type: " + property.getPropertyType());
					Text propertyVacanyStatus = new Text("Property Vacany Status: "
							+ (property.getVacancy() ? "Property is Vacant" : "Property is not Vacant"));
					Text propertyNumber = new Text(
							"Apartment Number: " + ((ApartmentModel) property).getApartmentNumber());
					Text propertyCivicNumber = new Text(
							"Apartment Civic Number: " + ((ApartmentModel) property).getCivicAddress());
					Text propertyStreet = new Text("Street is: " + property.getStreetName());
					Text propertyCity = new Text("City is: " + property.getCity());
					Text properyProvince = new Text("Province is: " + property.getProvince());
					Text propertyCountry = new Text("Country is: " + property.getCountry());
					Text propertyPostalCode = new Text("Postal Code is: " + property.getPostalCode());
					Text propertyBedroomCount = new Text(
							"Number of Bedrooms: " + ((ApartmentModel) property).getNumberOfBedRooms());
					Text propertyBathromCount = new Text(
							"Number of Bathrooms: " + ((ApartmentModel) property).getNumberOfBathrooms());
					Text propertySquareFootage = new Text(
							"Size of Apartment: " + ((ApartmentModel) property).getSquareFootage());
					Text propertyRent = new Text("Rent is: " + property.getRent());
					Text renovationNeeded = new Text("Renovation needed for the property: "
							+ (property.getRenovationUpdateStatus() ? "Yes" : "No"));
					fPane.getChildren().addAll(propertyID, typeOfProperty, propertyVacanyStatus, propertyNumber,
							propertyCivicNumber, propertyStreet, propertyCity, properyProvince, propertyCountry,
							propertyPostalCode, propertyBedroomCount, propertyBathromCount, propertySquareFootage,
							propertyRent, renovationNeeded);
				} else if (property.getPropertyType().equalsIgnoreCase("Condo")) {
					Text propertyID = new Text("PropertyID: " + String.valueOf(property.getPropertyID()));
					Text typeOfProperty = new Text("Property Type: " + property.getPropertyType());
					Text propertyVacanyStatus = new Text("Property Vacany Status: "
							+ (property.getVacancy() ? "Property is Vacant" : "Property is not Vacant"));
					Text propertyNumber = new Text("Condo Unit Number: " + ((CondoModel) property).getUnitNumber());
					Text propertyCivicNumber = new Text(
							"Condo Street Number: " + ((CondoModel) property).getStreetNumber());
					Text propertyStreet = new Text("Street is: " + property.getStreetName());
					Text propertyCity = new Text("City is: " + property.getCity());
					Text properyProvince = new Text("Province is: " + property.getProvince());
					Text propertyCountry = new Text("Country is: " + property.getCountry());
					Text propertyPostalCode = new Text("Postal Code is: " + property.getPostalCode());
					Text propertyRent = new Text("Rent is: " + property.getRent());
					Text renovationNeeded = new Text("Renovation needed for the property: "
							+ (property.getRenovationUpdateStatus() ? "Yes" : "No"));
					fPane.getChildren().addAll(propertyID, typeOfProperty, propertyVacanyStatus, propertyNumber,
							propertyCivicNumber, propertyStreet, propertyCity, properyProvince, propertyCountry,
							propertyPostalCode, propertyRent, renovationNeeded);
				} else if (property.getPropertyType().equalsIgnoreCase("House")) {
					Text propertyID = new Text("PropertyID: " + String.valueOf(property.getPropertyID()));
					Text typeOfProperty = new Text("Property Type: " + property.getPropertyType());
					Text propertyVacanyStatus = new Text("Property Vacany Status: "
							+ (property.getVacancy() ? "Property is Vacant" : "Property is not Vacant"));

					Text propertyCivicNumber = new Text(
							"Condo Street Number: " + ((HouseModel) property).getStreetNumber());
					Text propertyStreet = new Text("Street is: " + property.getStreetName());
					Text propertyCity = new Text("City is: " + property.getCity());
					Text properyProvince = new Text("Province is: " + property.getProvince());
					Text propertyCountry = new Text("Country is: " + property.getCountry());
					Text propertyPostalCode = new Text("Postal Code is: " + property.getPostalCode());
					Text propertyRent = new Text("Rent is: " + property.getRent());
					Text renovationNeeded = new Text("Renovation needed for the property: "
							+ (property.getRenovationUpdateStatus() ? "Yes" : "No"));
					fPane.getChildren().addAll(propertyID, typeOfProperty, propertyVacanyStatus, propertyCivicNumber,
							propertyStreet, propertyCity, properyProvince, propertyCountry, propertyPostalCode,
							propertyRent, renovationNeeded);
				}

				fPane.setMinHeight(300);
				fPane.setMaxHeight(300);
				fPane.setMinWidth(300);
				fPane.setMaxWidth(300);
				fPane.setOrientation(Orientation.VERTICAL);
				card.setCenter(fPane);
				GridPane.setMargin(card, new Insets(20));
				root.add(card, col, row);
			
				++col;
				if (col == 4) {
					col = 0;
					++row;
				}
			}
			Button homeScreenButton = new Button("Go Home Screen");
		

			homeScreenButton.setOnAction((event) -> {
				this.goHomeButtonClickListener(event);
			});
			globalRoot.addRow(0, root);
			globalRoot.addRow(1, homeScreenButton);
			globalRoot.setAlignment(Pos.CENTER);
			GridPane.setHalignment(homeScreenButton, javafx.geometry.HPos.CENTER);
	        GridPane.setValignment(homeScreenButton, javafx.geometry.VPos.CENTER);
			Scene displayPropertyScene = new Scene(scrollPane);
			sceneCtrl.addScene("Display Property", displayPropertyScene);
			sceneCtrl.switchToScene("Display Property");
			displayPropertyScene.getStylesheets().add(
					getClass().getResource("/main/styles/Tenant_Management_Main_Class_Style.css").toExternalForm());
		}
	}

	@Override
	public void run() {
		System.out.println("Display Property: " + Thread.currentThread().getName());
		DisplayPropertyView dView = new DisplayPropertyView();
		
		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				if(propertyFlag.equalsIgnoreCase("All Property")) {
					dView.setPropertyData(propertyFlag);
				}
				else if(propertyFlag.equalsIgnoreCase("Rented Property")) {
					dView.setPropertyData(propertyFlag);
				}
				else if(propertyFlag.equalsIgnoreCase("Vacant Property")) {
					dView.setPropertyData(propertyFlag);
				}
				dView.loadUI();
			}

		});
	}

}

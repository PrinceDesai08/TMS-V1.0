package main.util.builder;

import main.view.TenantView;

public class TenantViewBuilder {
   public TenantView build() {
	   return new TenantView();
   }
}

package main.util.builder;

import main.view.TenantView;

public class TenantViewModelBuilder {
    public TenantView build() {
    	return new TenantView();
    }
}
